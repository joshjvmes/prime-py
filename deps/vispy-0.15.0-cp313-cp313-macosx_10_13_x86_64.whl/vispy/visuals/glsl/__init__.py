"""Repository of common GLSL functions."""
